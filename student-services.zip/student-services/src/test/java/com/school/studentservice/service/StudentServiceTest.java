package com.school.studentservice.service;

import com.school.studentservice.entity.Student;
import com.school.studentservice.repository.StudentRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class StudentServiceTest {

    @Mock
    private StudentRepository studentRepository;

    @InjectMocks
    private StudentService studentService;

    
    @Test
    void testSaveStudent() {
        Student student = new Student();
        student.setId(1);
        student.setName("Rahul");

        when(studentRepository.save(student)).thenReturn(student);

        Student saved = studentService.saveStudent(student);

        assertNotNull(saved);
        assertEquals("Rahul", saved.getName());
        verify(studentRepository, times(1)).save(student);
    }

    // ✅ Test: get all students
    @Test
    void testGetAllStudents() {
        Student s1 = new Student();
        s1.setName("A");

        Student s2 = new Student();
        s2.setName("B");

        when(studentRepository.findAll()).thenReturn(Arrays.asList(s1, s2));

        List<Student> students = studentService.getAllStudents();

        assertEquals(2, students.size());
        verify(studentRepository, times(1)).findAll();
    }

    // ✅ Test: get student by id (success)
    @Test
    void testGetStudentById() {
        Student student = new Student();
        student.setId(1);
        student.setName("Anita");

        when(studentRepository.findById(1)).thenReturn(Optional.of(student));

        Student result = studentService.getStudentById(1);

        assertEquals("Anita", result.getName());
        verify(studentRepository).findById(1);
    }

    // ✅ Test: get student by id (not found)
    @Test
    void testGetStudentById_NotFound() {
        when(studentRepository.findById(99)).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(
                RuntimeException.class,
                () -> studentService.getStudentById(99)
        );

        assertEquals("Student not found", exception.getMessage());
    }

    // ✅ Test: delete student
    @Test
    void testDeleteStudent() {
        doNothing().when(studentRepository).deleteById(1);

        studentService.deleteStudent(1);

        verify(studentRepository, times(1)).deleteById(1);
    }
}
