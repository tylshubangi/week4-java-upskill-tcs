package com.school.studentservice.aop;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

import java.util.Arrays;

@Aspect
@Component
public class LoggingAspect {

	@Around("execution(* com.school.studentservice.controller..*(..))")
	public Object logMethodExecution(ProceedingJoinPoint joinPoint) throws Throwable {

		long startTime = System.currentTimeMillis();

		// Method name
		String methodName = joinPoint.getSignature().toShortString();

		// Arguments
		Object[] args = joinPoint.getArgs();

		System.out.println("▶ Method called: " + methodName);
		System.out.println("▶ Arguments: " + Arrays.toString(args));

		// Execute actual method
		Object result = joinPoint.proceed();

		long endTime = System.currentTimeMillis();

		// Execution time
		System.out.println("▶ Execution time: " + (endTime - startTime) + " ms");
		System.out.println("--------------------------------------------------");

		return result;
	}
}
